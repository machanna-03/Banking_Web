import React from 'react'
import SendOTP from './SendOtp'
import { Header } from './Header'

export const Home = () => {
  return (
    <div>
        <SendOTP/>
        {/* <Header /> */}
    </div>
  )
}
