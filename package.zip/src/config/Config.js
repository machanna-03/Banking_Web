export const config = {
    banking: "http://localhost:8080",
    cookieName: "b_user",
    sessionCookie: "b_sess",
  };